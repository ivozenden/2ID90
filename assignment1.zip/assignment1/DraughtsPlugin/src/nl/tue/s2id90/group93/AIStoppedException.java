package nl.tue.s2id90.group93;

/**
 *
 * @author huub
 */
public class AIStoppedException extends Exception { }
