package nl.tue.s2id90.draughts;

import net.xeoh.plugins.base.Plugin;

/**
 * Marker interface, that marks an implementing class as suitable for usage in DraughtsCompetitionGUI.
 * @author huub
 */
public interface DraughtsPlugin extends Plugin {
    
}
